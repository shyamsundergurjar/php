
<?php
// username = "admin@admin.com"
// passwoed = "1234"

if($_SERVER['REQUEST_METHOD'] =='POST'){
    $email = $_POST['email'];
    $password = $_POST['password'];

    
    if(empty($email)  || empty($password))
    {
        header("location: login.php");
    }
    else 
        if($email==="admin@admin.com" && $password=== "12345")
         {
             header("Location: admin/index.php");
        }
         else
         {
        header("Location: login.php");
        
        }
    }
    elseif($_SERVER["REQUEST_METHOD"] == 'GET')
    {
        
    }
?>